/**
 * Data Comparison Tool v2.0 — Frontend Application
 * Bug-fixed production build
 *
 * Fixed bugs:
 * 1. showView() now sets display style directly (inline style beats CSS class)
 * 2. azureSearch() alias added (called from HTML)
 * 3. Toggle option reading fixed (null-safe boolean)
 * 4. _checkBoth() now enables az-next-btn for Azure flow
 * 5. _show() enhanced with flex-mode for flex containers
 * 6. _populateCatBrand() always repopulates (removed stale-cache guard)
 * 7. detailSearch debounce fixed
 * 8. Progress.update() updates overlay-msg element
 * 9. Azure: file selection flow hardened
 * 10. Azure: azureSetSide() works without pre-selecting blob when called from quick-set
 */
'use strict';

/* ─── STATE ────────────────────────────────────────────────────────────────── */
const State = {
  sessionId: null,
  source: null,
  files: { internal: null, vendor: null },
  mappings: [],
  comparisonResult: null,
  jobId: null,
  jobPollInterval: null,
  charts: {},
  filterRules: [],
  filterValues: [],
  pagination: {
    detail: { page: 1, pageSize: 100 },
    sku:    { page: 1, pageSize: 50  },
    diff:   { page: 1, pageSize: 50  },
  },
  azure: {
    connected: false,
    accountName: null,
    container: null,
    prefix: '',
    cache: {},
    allFiles: [],
    filteredFiles: [],
    sortKey: 'name',
    sortAsc: true,
    selectedBlob: null,
    files: { internal: null, vendor: null },
    searchQuery: '',
  },
};

/* ─── API CLIENT ───────────────────────────────────────────────────────────── */
const API = {
  base: '/api',
  hdr() { return { 'x-session-id': State.sessionId, 'Content-Type': 'application/json' }; },

  async get(path) {
    const r = await fetch(this.base + path, { headers: this.hdr() });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
    return r.json();
  },
  async post(path, body) {
    const r = await fetch(this.base + path, { method: 'POST', headers: this.hdr(), body: JSON.stringify(body) });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
    return r.json();
  },
  async del(path) {
    const r = await fetch(this.base + path, { method: 'DELETE', headers: this.hdr() });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
    return r.json();
  },
  upload(path, fd, onPct) {
    return new Promise((ok, fail) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', this.base + path);
      xhr.setRequestHeader('x-session-id', State.sessionId);
      xhr.upload.onprogress = e => { if (e.lengthComputable && onPct) onPct(Math.round(e.loaded / e.total * 100)); };
      xhr.onload = () => {
        try { const d = JSON.parse(xhr.responseText); xhr.status < 300 ? ok(d) : fail(new Error(d.error || xhr.statusText)); }
        catch { fail(new Error(xhr.statusText)); }
      };
      xhr.onerror = () => fail(new Error('Network error'));
      xhr.send(fd);
    });
  },
};

/* ─── HELPERS (defined first so they can be used everywhere) ───────────────── */
function $(id) { return document.getElementById(id); }
function $el(tag, attrs) {
  const e = document.createElement(tag);
  if (attrs) Object.entries(attrs).forEach(([k, v]) => k === 'class' ? (e.className = v) : e.setAttribute(k, v));
  return e;
}
function _esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function _size(b) {
  if (!b || b < 0) return '0 B';
  const k = 1024, u = ['B','KB','MB','GB'];
  const i = Math.min(3, Math.floor(Math.log(Math.max(b,1)) / Math.log(k)));
  return (b / Math.pow(k, i)).toFixed(1) + ' ' + u[i];
}
/* BUG-FIX: _show now accepts optional 'flex' mode for flex containers */
function _show(id, visible, displayVal) {
  const e = $(id);
  if (e) e.style.display = visible ? (displayVal || '') : 'none';
}
function _showFlex(id, visible) { _show(id, visible, 'flex'); }
function _text(id, val) { const e = $(id); if (e) e.textContent = String(val); }
function _html(id, val) { const e = $(id); if (e) e.innerHTML = val; }
function _bar(id, pct) { const e = $(id); if (e) e.style.width = Math.min(100, Math.max(0, pct)) + '%'; }
function _disabled(id, v) { const e = $(id); if (e) e.disabled = !!v; }
function _badge(id, text, cls) { const e = $(id); if (!e) return; e.textContent = text; e.className = 'badge ' + cls; }
function _dot(dId, lId, on, onT, offT) {
  const d = $(dId); if (d) d.className = 'dot' + (on ? '' : ' off');
  const l = $(lId); if (l) l.textContent = on ? onT : offT;
}
/* BUG-FIX: isKey helper for auto-selecting key columns */
function _isKey(col) {
  return /^(sku|ean|barcode|upc|id|code|item_no|article|product_code)$/i.test(
    col.toLowerCase().replace(/[^a-z0-9]/g, '')
  );
}
function _triggerDownload(url, filename) {
  const a = document.createElement('a'); a.href = url; a.download = filename || 'download';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
}
/* BUG-FIX: _debounce defined before any usage */
function _debounce(fn, ms) {
  let t;
  return function(...a) { clearTimeout(t); t = setTimeout(() => fn.apply(this, a), ms); };
}
/* BUG-FIX: read toggle switch safely */
function _toggle(id, defaultVal) {
  const e = $(id);
  if (!e) return defaultVal !== undefined ? defaultVal : true;
  return e.classList.contains('on');
}

/* ─── TOAST ────────────────────────────────────────────────────────────────── */
const Toast = {
  show(msg, type = 'info', duration = 4500) {
    let c = $('toast-container');
    if (!c) {
      c = $el('div', { id: 'toast-container', style: 'position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:10px;pointer-events:none;max-width:380px' });
      document.body.appendChild(c);
    }
    const icons = { success: 'ti-check-circle', error: 'ti-alert-circle', warning: 'ti-alert-triangle', info: 'ti-info-circle' };
    const cols  = { success: 'var(--green)', error: 'var(--red)', warning: 'var(--amber)', info: 'var(--blue)' };
    const t = $el('div', { class: `toast toast-${type}` });
    t.style.cssText = 'pointer-events:all;animation:slideUp .22s ease';
    t.innerHTML = `<i class="ti ${icons[type] || icons.info} toast-icon" style="color:${cols[type] || cols.info}"></i><div class="toast-content"><div class="toast-title">${_esc(msg)}</div></div><span class="toast-close" onclick="this.closest('.toast').remove()">×</span>`;
    c.appendChild(t);
    setTimeout(() => { t.style.transition = 'opacity .3s'; t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, duration);
  },
  success: (m, d) => Toast.show(m, 'success', d),
  error:   (m, d) => Toast.show(m, 'error',   d || 7000),
  warning: (m, d) => Toast.show(m, 'warning', d),
  info:    (m, d) => Toast.show(m, 'info',    d),
};

/* ─── PROGRESS OVERLAY ─────────────────────────────────────────────────────── */
const Progress = {
  show(msg = 'Processing…', pct = null) {
    const ov = $('progress-overlay');
    if (ov) ov.style.display = 'flex';
    this.update(msg, pct);
  },
  /* BUG-FIX: also update overlay-msg element */
  update(msg, pct) {
    if (msg) {
      _text('overlay-title', msg);
      _text('overlay-msg',   msg);
    }
    if (pct !== null && pct !== undefined) {
      _bar('overlay-bar', pct);
      _text('overlay-pct', Math.round(pct) + '%');
    }
  },
  hide() {
    const ov = $('progress-overlay');
    if (ov) ov.style.display = 'none';
  },
};

/* ─── ACTIVITY LOG (SSE) ────────────────────────────────────────────────────── */
const Activity = {
  sse: null,
  unread: 0,

  init() {
    if (this.sse) { try { this.sse.close(); } catch {} }
    this.sse = new EventSource(`/api/activity/stream?sessionId=${encodeURIComponent(State.sessionId)}`);
    this.sse.onmessage = (e) => {
      try {
        const d = JSON.parse(e.data);
        if (d.type === 'ping') return;
        this._add(d);
        if (d.type === 'progress' && d.pct != null) Progress.update(d.message || 'Processing…', d.pct);
      } catch {}
    };
    this.sse.onerror = () => {}; // reconnects automatically
  },

  _add(d) {
    const list = $('activity-log-list');
    if (!list) return;
    const typeClass = { info:'activity-info', success:'activity-success', warning:'activity-warning', error:'activity-error', progress:'activity-progress' };
    const icons     = { info:'ti-info-circle', success:'ti-check-circle', warning:'ti-alert-triangle', error:'ti-alert-circle', progress:'ti-loader spin' };
    const item = $el('div', { class: `activity-item ${typeClass[d.type] || 'activity-info'}` });
    item.innerHTML = `<div style="display:flex;align-items:center;gap:6px"><i class="ti ${icons[d.type] || 'ti-info-circle'}" style="font-size:13px;flex-shrink:0"></i><span>${_esc(d.message || '')}</span></div><div class="activity-time">${new Date().toLocaleTimeString()}</div>`;
    list.prepend(item);
    while (list.children.length > 150) list.lastChild.remove();
    const panel = $('activity-panel');
    if (!panel || panel.style.display !== 'flex') {
      this.unread++;
      const badge = $('activity-unread');
      if (badge) { badge.textContent = this.unread; badge.style.display = ''; }
    }
  },
};

/* ─── SESSION ──────────────────────────────────────────────────────────────── */
function initSession() {
  let sid = localStorage.getItem('dct-sid');
  if (!sid) {
    sid = (typeof crypto !== 'undefined' && crypto.randomUUID)
      ? crypto.randomUUID()
      : 'sess-' + Math.random().toString(36).slice(2) + Date.now();
    localStorage.setItem('dct-sid', sid);
  }
  State.sessionId = sid;
  Activity.init();
}

/* ─── TABS ──────────────────────────────────────────────────────────────────── */
function initTabs() {
  document.querySelectorAll('.tabs').forEach(group => {
    group.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', () => {
        const id = tab.dataset.tab;
        group.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const scope = group.closest('.view') || document;
        scope.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
        const panel = scope.querySelector('#' + id) || document.getElementById(id);
        if (panel) panel.classList.add('active');
      });
    });
  });
}

/* ═══════════════════════════════════════════════════════════════════════════════
   APP
═══════════════════════════════════════════════════════════════════════════════ */
const App = {

  /* ── VIEW NAVIGATION ───────────────────────────────────────────────────────
     CSS handles visibility: .view { display:none } and .view.active { display:block }
     We simply toggle the 'active' class - no inline styles needed */
  showView(name) {
    /* Toggle active class - CSS .view rule hides all, .view.active shows one */
    document.querySelectorAll('.view').forEach(v => {
      v.classList.remove('active');
      v.style.display = ''; /* clear any lingering inline style */
    });
    const v = $('view-' + name);
    if (v) { v.classList.add('active'); }

    /* Sidebar highlight */
    document.querySelectorAll('.sb-item').forEach(i => i.classList.remove('active'));
    document.querySelectorAll(`.sb-item[data-view="${name}"]`).forEach(i => i.classList.add('active'));

    /* Step bar */
    const steps = ['upload', 'schema', 'configure', 'results'];
    document.querySelectorAll('.step').forEach(s => {
      s.classList.remove('active', 'done');
      const si = steps.indexOf(s.dataset.view), ni = steps.indexOf(name);
      if (si >= 0 && ni >= 0) {
        if      (si < ni) s.classList.add('done');
        else if (si === ni) s.classList.add('active');
      }
    });

    /* Breadcrumb */
    const BC = { upload:'Load Files', schema:'Schema Map', configure:'Configure', results:'Results', sku:'SKU Analysis', diff:'Field Differences', category:'Category Map', brand:'Brand Analysis', performance:'Performance', export:'Export Reports' };
    _text('breadcrumb-label', BC[name] || name);
    State.currentView = name;

    /* View-specific init */
    if (name === 'results')     { if (State.comparisonResult) this._renderResults(); else this._showResultsEmpty(); }
    if (name === 'export')      { this._updateExportView(); this.loadReportList(); }
    if (name === 'configure')   this._populateConfigure();
    if (name === 'category')    this._populateCatBrand();
    if (name === 'brand')       this._populateCatBrand();
    if (name === 'sku')         {
      if (State.comparisonResult) { _show('sku-empty-state',false); _show('sku-content',true); this.loadSkuPage(1); }
      else                        { _show('sku-empty-state',true);  _show('sku-content',false); }
    }
    if (name === 'diff')        {
      if (State.comparisonResult) { _show('diff-empty-state',false); _show('diff-content',true); this.loadDiffPage(1); }
      else                        { _show('diff-empty-state',true);  _show('diff-content',false); }
    }
    if (name === 'performance') this._renderPerformance();
  },

  /* ── SOURCE SELECTION ───────────────────────────────────────────────────── */
  chooseSource(src) {
    State.source = src;
    _show('up-screen-choose', !src);
    _show('up-screen-local',  src === 'local');
    _show('up-screen-azure',  src === 'azure');
  },

  /* ── LOCAL FILE UPLOAD ──────────────────────────────────────────────────── */
  handleDrop(e, side) {
    e.preventDefault();
    e.currentTarget.classList.remove('drag-over');
    const f = e.dataTransfer.files[0];
    if (f) this._upload(f, side);
  },

  handleFileSelect(e, side) {
    const f = e.target.files[0];
    if (f) this._upload(f, side);
    e.target.value = '';
  },

  async _upload(file, side) {
    const EXTS = ['.csv','.xlsx','.xls','.xlsm','.tsv','.txt','.zip'];
    const ext  = '.' + file.name.split('.').pop().toLowerCase();
    if (!EXTS.includes(ext)) { Toast.error(`Unsupported file type: ${ext}`); return; }
    if (file.size > 500 * 1024 * 1024) { Toast.error('File too large (max 500 MB)'); return; }

    const isInt  = side === 'internal';
    const wrapId = isInt ? 'int-progress'      : 'vnd-progress';
    const barId  = isInt ? 'int-progress-bar'  : 'vnd-progress-bar';
    const pctId  = isInt ? 'int-progress-pct'  : 'vnd-progress-pct';
    const lblId  = isInt ? 'int-progress-label': 'vnd-progress-label';
    const infoId = isInt ? 'int-file-info'     : 'vnd-file-info';
    const badgeId= isInt ? 'int-badge'         : 'vnd-badge';

    _show(infoId, false);
    _show(wrapId, true);
    _bar(barId, 0); _text(pctId, '0%'); _text(lblId, `Uploading ${file.name}…`);
    _badge(badgeId, 'Uploading…', isInt ? 'badge-blue' : 'badge-purple');

    try {
      const fd = new FormData(); fd.append('file', file);
      const data = await API.upload(`/files/upload/${side}`, fd, pct => {
        _bar(barId, pct); _text(pctId, pct + '%');
      });
      _show(wrapId, false);
      State.files[side] = data;
      this._showFileCard(side, data);
      Toast.success(`${isInt ? 'Internal' : 'Vendor'} file loaded: ${file.name}`);
      this._updateStatus();
      this._checkBoth();
    } catch (err) {
      _show(wrapId, false);
      _badge(badgeId, 'Error', 'badge-red');
      Toast.error('Upload failed: ' + err.message);
    }
  },

  _showFileCard(side, data) {
    const isInt  = side === 'internal';
    const infoId = isInt ? 'int-file-info' : 'vnd-file-info';
    const badgeId= isInt ? 'int-badge'     : 'vnd-badge';
    _badge(badgeId, 'Loaded', isInt ? 'badge-blue' : 'badge-purple');
    const infoEl = $(infoId); if (!infoEl) return;

    const rowCount = (data.rowCount || data.rows || 0).toLocaleString();
    const colCount = (data.columns || []).length;
    const color    = isInt ? '#2563eb' : '#7c3aed';
    const keys     = data.keyColumns || [];
    infoEl.innerHTML = `
      <div style="display:flex;align-items:flex-start;gap:12px;padding:12px;background:#f0fdf4;border-radius:8px;border:1px solid #bbf7d0;margin-top:10px">
        <div style="width:40px;height:40px;border-radius:8px;background:${color};display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="ti ti-file-check" style="color:#fff;font-size:18px"></i>
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-weight:700;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${_esc(data.filename||data.originalName||'')}">${_esc(data.filename||data.originalName||'File')}</div>
          <div style="font-size:11px;color:#6b7280;margin-top:3px">${rowCount} rows · ${colCount} cols · ${_size(data.size)}</div>
          ${keys.length ? `<div style="margin-top:5px;display:flex;gap:4px;flex-wrap:wrap">${keys.slice(0,3).map(k=>`<span style="background:#dcfce7;color:#166534;padding:1px 7px;border-radius:4px;font-size:10px;font-weight:700">${_esc(k)}</span>`).join('')}<span style="font-size:10px;color:#6b7280">suggested key${keys.length>1?'s':''}</span></div>` : ''}
        </div>
        <button onclick="App._clearFile('${side}')" style="background:none;border:none;cursor:pointer;color:#9ca3af;padding:4px;line-height:1" title="Remove file"><i class="ti ti-x"></i></button>
      </div>`;
    infoEl.style.display = 'block';
  },

  _clearFile(side) {
    State.files[side] = null;
    const isInt = side === 'internal';
    const infoEl = $(isInt ? 'int-file-info' : 'vnd-file-info');
    if (infoEl) { infoEl.style.display = 'none'; infoEl.innerHTML = ''; }
    _badge(isInt ? 'int-badge' : 'vnd-badge', 'Not loaded', 'badge-gray');
    this._updateStatus();
    this._checkBoth();
  },

  /* BUG-FIX: also enables az-next-btn for Azure flow */
  _checkBoth() {
    const ok = !!(State.files.internal && State.files.vendor);
    _disabled('btn-next-schema', !ok);
    _disabled('az-next-btn', !ok);
    if (ok) Toast.info('Both files loaded — click "Continue to Schema Map".');
  },

  /* ── SCHEMA MAP ─────────────────────────────────────────────────────────── */
  async goToSchema() {
    if (!State.files.internal || !State.files.vendor) { Toast.warning('Load both files first'); return; }
    Progress.show('Analysing schemas…', 30);
    try {
      const [intInfo, vndInfo] = await Promise.all([
        API.get('/files/info/internal'),
        API.get('/files/info/vendor'),
      ]);
      State.files.internal = { ...State.files.internal, ...intInfo };
      State.files.vendor   = { ...State.files.vendor,   ...vndInfo };
      this._renderSchema(intInfo, vndInfo);
      Progress.hide();
      this.showView('schema');
    } catch (err) { Progress.hide(); Toast.error('Schema error: ' + err.message); }
  },

  _renderSchema(intInfo, vndInfo) {
    const iCols = intInfo.columns || [], vCols = vndInfo.columns || [];
    _text('int-col-count', iCols.length + ' cols');
    _text('vnd-col-count', vCols.length + ' cols');

    const mkList = (cols, types, color) => cols.map(c =>
      `<div style="padding:3px 6px;border-radius:4px;font-size:12px;display:flex;align-items:center;gap:6px;margin-bottom:1px">
        <code style="color:${color};font-size:11px">${_esc(c)}</code>
        <span style="font-size:10px;color:#9ca3af;margin-left:auto">${_esc((types||{})[c]||'')}</span>
      </div>`
    ).join('');

    const iList = $('int-schema-list'), vList = $('vnd-schema-list');
    if (iList) iList.innerHTML = mkList(iCols, intInfo.columnTypes, '#2563eb');
    if (vList) vList.innerHTML = mkList(vCols, vndInfo.columnTypes, '#7c3aed');

    this._buildMappingRows(iCols, vCols);
  },

  _buildMappingRows(iCols, vCols) {
    const c = $('mapping-rows'); if (!c) return;
    c.innerHTML = '';
    const norm = s => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    const used = new Set(), pairs = [];
    iCols.forEach(ic => {
      const vc = vCols.find(v => !used.has(v) && norm(v) === norm(ic));
      if (vc) { used.add(vc); pairs.push({ i: ic, v: vc }); }
    });
    if (!pairs.length && iCols.length && vCols.length) pairs.push({ i: iCols[0], v: vCols[0] });
    State.mappings = pairs.map(p => ({ internal: p.i, vendor: p.v }));
    pairs.forEach(p => this._addMapRow(p.i, p.v, iCols, vCols));
    _text('mapping-stats', pairs.length + ' mapped');
    _show('mapping-empty', !pairs.length);
  },

  _addMapRow(iv, vv, iCols, vCols) {
    if (!iCols) iCols = State.files.internal?.columns || [];
    if (!vCols) vCols = State.files.vendor?.columns   || [];
    const c = $('mapping-rows'); if (!c) return;
    const norm = s => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const conf = iv && vv ? (norm(iv) === norm(vv) ? 'Exact' : 'Fuzzy') : '—';
    const confBadge = iv && vv
      ? (conf === 'Exact' ? '<span class="badge badge-match">Exact</span>' : '<span class="badge badge-amber">Fuzzy</span>')
      : '';
    const row = $el('div', { class: 'map-row' });
    row.innerHTML = `
      <select class="map-sel-int" style="font-size:12px">
        <option value="">— Internal —</option>
        ${iCols.map(col => `<option value="${_esc(col)}"${col===iv?' selected':''}>${_esc(col)}</option>`).join('')}
      </select>
      <i class="ti ti-arrows-right-left" style="color:#9ca3af;text-align:center"></i>
      <select class="map-sel-vnd" style="font-size:12px">
        <option value="">— Vendor —</option>
        ${vCols.map(col => `<option value="${_esc(col)}"${col===vv?' selected':''}>${_esc(col)}</option>`).join('')}
      </select>
      <div style="text-align:center">${confBadge}</div>
      <button class="btn btn-sm btn-ghost" onclick="this.closest('.map-row').remove();App._syncMapStats()" title="Remove"><i class="ti ti-x"></i></button>`;
    c.appendChild(row);
  },

  _syncMapStats() { _text('mapping-stats', document.querySelectorAll('.map-row').length + ' mapped'); },

  addMappingRow() { this._addMapRow('', '', null, null); },

  async autoSuggestMappings() {
    if (!State.files.internal || !State.files.vendor) { Toast.warning('Load both files first'); return; }
    Progress.show('Auto-suggesting column mappings…', 40);
    try {
      const data = await API.post('/comparison/suggest-mappings', {});
      Progress.hide();
      if (!data.mappings?.length) { Toast.warning('No strong matches found — add mappings manually.'); return; }
      const c = $('mapping-rows'); if (c) c.innerHTML = '';
      State.mappings = data.mappings;
      data.mappings.forEach(m => this._addMapRow(m.internal, m.vendor, State.files.internal?.columns, State.files.vendor?.columns));
      _text('mapping-stats', data.mappings.length + ' mapped');
      Toast.success(`${data.mappings.length} mappings suggested (avg. ${Math.round(data.avgConfidence || 0)}% confidence)`);
    } catch (err) { Progress.hide(); Toast.error('Auto-suggest failed: ' + err.message); }
  },

  saveMappingConfig() {
    State.mappings = [...document.querySelectorAll('.map-row')]
      .map(r => ({ internal: r.querySelector('.map-sel-int')?.value, vendor: r.querySelector('.map-sel-vnd')?.value }))
      .filter(m => m.internal && m.vendor);
    Toast.success(`Saved ${State.mappings.length} column mappings`);
  },

  /* ── CONFIGURE ──────────────────────────────────────────────────────────── */
  _populateConfigure() {
    const iCols = State.files.internal?.columns || [];
    const vCols = State.files.vendor?.columns   || [];
    const all   = [...new Set([...iCols, ...vCols])];

    const fillMulti = (id, cols, autoKey) => {
      const el = $(id); if (!el) return;
      const prev = [...el.selectedOptions].map(o => o.value);
      el.innerHTML = cols.map(c =>
        `<option value="${_esc(c)}"${(prev.includes(c) || (autoKey && !prev.length && _isKey(c))) ? ' selected' : ''}>${_esc(c)}</option>`
      ).join('');
    };
    fillMulti('int-key-select',     iCols, true);
    fillMulti('vnd-key-select',     vCols, true);
    fillMulti('ignore-cols-select', all,   false);

    const ig = $('filter-int-optgroup'), vg = $('filter-vnd-optgroup');
    if (ig) ig.innerHTML = iCols.map(c => `<option>${_esc(c)}</option>`).join('');
    if (vg) vg.innerHTML = vCols.map(c => `<option>${_esc(c)}</option>`).join('');
  },

  toggleFilterPanel(el) {
    el.classList.toggle('on');
    _show('filter-panel-body', el.classList.contains('on'));
  },

  async filterColChanged() {
    const col = $('filter-col-select')?.value;
    _show('filter-value-area', !!col);
    if (!col) return;
    try {
      const data = await API.post('/comparison/filter-values', { column: col });
      State.filterValues = data.values || [];
      this._renderFilterVals(State.filterValues);
    } catch (err) { Toast.error('Failed to load values: ' + err.message); }
  },

  _renderFilterVals(vals) {
    const list = $('filter-val-list'); if (!list) return;
    list.innerHTML = vals.map(v =>
      `<label style="display:flex;align-items:center;gap:6px;font-size:12px;padding:4px 8px;border-bottom:1px solid #f3f4f6;cursor:pointer">
        <input type="checkbox" value="${_esc(String(v))}" checked> ${_esc(String(v))}
      </label>`
    ).join('');
    _text('filter-val-count', `(${vals.length} values)`);
  },

  filterValSearch(q)  { this._renderFilterVals(State.filterValues.filter(v => String(v).toLowerCase().includes(q.toLowerCase()))); },
  filterSelectAll()   { document.querySelectorAll('#filter-val-list input').forEach(cb => cb.checked = true); },
  filterClearAll()    { document.querySelectorAll('#filter-val-list input').forEach(cb => cb.checked = false); },

  addFilterRule() {
    const col  = $('filter-col-select')?.value;
    const vals = [...document.querySelectorAll('#filter-val-list input:checked')].map(cb => cb.value);
    if (!col)         { Toast.warning('Select a column first'); return; }
    if (!vals.length) { Toast.warning('Select at least one value'); return; }
    State.filterRules.push({ column: col, values: vals });
    this._renderFilterRules();
    Toast.success(`Filter added: ${col} (${vals.length} values)`);
  },

  _renderFilterRules() {
    const list = $('filter-rules-list');
    const wrap = $('active-filter-chips');
    const chips= $('filter-chips-container');
    if (!list) return;
    list.innerHTML = State.filterRules.map((r, i) =>
      `<div style="display:flex;align-items:center;gap:8px;background:#f0f9ff;padding:7px 10px;border-radius:7px;margin-bottom:4px;font-size:12px;border:1px solid #bae6fd">
        <i class="ti ti-filter" style="color:#0284c7;flex-shrink:0"></i>
        <span style="flex:1"><strong>${_esc(r.column)}</strong> ∈ [${r.values.slice(0,3).map(_esc).join(', ')}${r.values.length>3?'…':''}]</span>
        <button class="btn btn-sm btn-ghost" onclick="App._rmFilter(${i})"><i class="ti ti-x"></i></button>
      </div>`
    ).join('');
    if (wrap)  wrap.style.display  = State.filterRules.length ? '' : 'none';
    if (chips) chips.innerHTML = State.filterRules.map((r, i) =>
      `<span class="chip chip-gray" style="cursor:pointer" onclick="App._rmFilter(${i})">${_esc(r.column)} ×</span>`
    ).join('');
  },

  _rmFilter(i) { State.filterRules.splice(i, 1); this._renderFilterRules(); },

  /* ── RUN COMPARISON ─────────────────────────────────────────────────────── */
  async runComparison() {
    if (!State.files.internal || !State.files.vendor) { Toast.warning('Load both files first.'); this.showView('upload'); return; }
    this.saveMappingConfig();

    /* BUG-FIX: use _toggle() to read toggle state safely (null-safe boolean) */
    const intKey = [...($('int-key-select')?.selectedOptions || [])].map(o => o.value).filter(Boolean)[0] || '';
    const vndKey = [...($('vnd-key-select')?.selectedOptions || [])].map(o => o.value).filter(Boolean)[0] || '';
    const ignore = [...($('ignore-cols-select')?.selectedOptions || [])].map(o => o.value);

    const body = {
      mappings:          State.mappings,
      keyColumnInternal: intKey,
      keyColumnVendor:   vndKey,
      options: {
        caseInsensitive: _toggle('opt-case',      true),
        trimWhitespace:  _toggle('opt-trim',      true),
        normalize:       _toggle('opt-normalize', false),
        ignoreColumns:   ignore,
      },
      filters: State.filterRules,
    };

    Progress.show('Submitting comparison job…', 8);
    try {
      const { jobId } = await API.post('/comparison/run', body);
      State.jobId = jobId;
      this._pollJob(jobId);
    } catch (err) { Progress.hide(); Toast.error('Failed to start: ' + err.message); }
  },

  _pollJob(jobId) {
    if (State.jobPollInterval) clearInterval(State.jobPollInterval);
    let polls = 0;
    State.jobPollInterval = setInterval(async () => {
      polls++;
      try {
        const job = await API.get(`/comparison/job/${jobId}`);
        if (job.status === 'running' || job.status === 'pending') {
          Progress.update(job.message || 'Processing…', Math.min(92, 10 + (job.progress || 0)));
        } else if (job.status === 'complete') {
          clearInterval(State.jobPollInterval);
          Progress.update('Loading results…', 96);
          await this._fetchResults();
          Progress.hide();
          Toast.success('Comparison complete!');
          this.showView('results');
          this._updateStatus();
        } else if (job.status === 'failed') {
          clearInterval(State.jobPollInterval);
          Progress.hide();
          Toast.error('Comparison failed: ' + (job.error || 'Unknown error'));
        } else if (polls > 300) {
          clearInterval(State.jobPollInterval);
          Progress.hide();
          Toast.error('Comparison timed out after 7.5 minutes.');
        }
      } catch (err) {
        clearInterval(State.jobPollInterval);
        Progress.hide();
        Toast.error('Poll error: ' + err.message);
      }
    }, 1500);
  },

  async _fetchResults() {
    const data = await API.get('/comparison/results?section=summary');
    State.comparisonResult = data;
  },

  /* ── RESULTS VIEW ──────────────────────────────────────────────────────── */
  _showResultsEmpty() { _show('results-empty', true); _show('results-content', false); },

  _renderResults() {
    const r = State.comparisonResult;
    const s = r?.summary;
    if (!s) { this._showResultsEmpty(); return; }
    _show('results-empty',   false);
    _show('results-content', true);

    /* Metrics strip */
    const mEl = $('results-metrics');
    if (mEl) mEl.innerHTML = [
      { label:'Total Internal',  val: s.totalInternal,                        color:'var(--blue)'  },
      { label:'Matched Exact',   val: s.matchedExact || s.matched,            color:'#10b981'      },
      { label:'With Diffs',      val: s.mismatched   || s.withDifferences||0, color:'#f59e0b'      },
      { label:'Missing Vendor',  val: s.missingInVendor,                      color:'#ef4444'      },
      { label:'Extra in Vendor', val: s.extraInVendor,                        color:'#8b5cf6'      },
    ].map(m => `<div class="metric metric-top" style="border-top-color:${m.color}"><div class="metric-val" style="color:${m.color}">${(m.val||0).toLocaleString()}</div><div class="metric-lbl">${m.label}</div></div>`).join('');

    /* Match rate bar */
    const rate = s.totalInternal > 0 ? Math.round((s.matched||0) / s.totalInternal * 100) : 0;
    const bar = $('match-rate-bar'); if (bar) bar.style.width = rate + '%';
    _text('match-rate-val', rate + '%');
    const badgeEl = $('match-rate-badge');
    if (badgeEl) {
      badgeEl.textContent = rate>=90?'Excellent':rate>=70?'Good':rate>=50?'Fair':'Poor';
      badgeEl.className   = `badge badge-${rate>=90?'match':rate>=70?'warn':'diff'}`;
    }

    /* Context chips */
    _html('ctx-int-file', `<i class="ti ti-building"></i> ${_esc(State.files.internal?.filename||State.files.internal?.originalName||'Internal')}`);
    _html('ctx-vnd-file', `<i class="ti ti-handshake"></i> ${_esc(State.files.vendor?.filename||State.files.vendor?.originalName||'Vendor')}`);
    _text('ctx-timestamp', 'at ' + new Date().toLocaleTimeString());

    this._renderSummaryTab(s, r?.schema);
    this._renderCharts(s);
    this._renderRecommendations(s);
    this.loadDetailPage(1);
  },

  _renderSummaryTab(s, schema) {
    const tbody = $('summary-counts-tbody');
    if (tbody) tbody.innerHTML = [
      ['Total Records',   s.totalInternal,                        s.totalVendor],
      ['Matched (exact)', s.matchedExact||s.matched,              s.matchedExact||s.matched],
      ['Mismatched',      s.mismatched||s.withDifferences||0,     s.mismatched||s.withDifferences||0],
      ['Missing / Extra', s.missingInVendor,                      s.extraInVendor],
      ['Duplicates',      s.duplicatesInternal||0,                s.duplicatesVendor||0],
    ].map(([l,a,b])=>`<tr><td>${l}</td><td><strong>${(a||0).toLocaleString()}</strong></td><td><strong>${(b||0).toLocaleString()}</strong></td></tr>`).join('');

    const sg = $('schema-summary-grid');
    if (sg && s.schemaSummary) {
      sg.innerHTML = [
        { val: s.schemaSummary.common,       label:'Shared',        color:'#10b981' },
        { val: s.schemaSummary.internalOnly, label:'Internal Only', color:'#ef4444' },
        { val: s.schemaSummary.vendorOnly,   label:'Vendor Only',   color:'#f59e0b' },
      ].map(m=>`<div class="metric metric-top" style="border-top-color:${m.color}"><div class="metric-val" style="color:${m.color}">${m.val||0}</div><div class="metric-lbl">${m.label}</div></div>`).join('');
    }

    const td = $('top-diffs-tbody');
    if (td && s.topDiffColumns?.length) {
      td.innerHTML = s.topDiffColumns.map(d => {
        const pct = s.matched > 0 ? Math.round(d.count/s.matched*100) : 0;
        return `<tr><td><strong>${_esc(d.column)}</strong></td><td>${d.count.toLocaleString()}</td><td>${pct}%</td><td><div style="background:#e5e7eb;border-radius:4px;height:6px;width:120px"><div style="width:${Math.min(100,pct)}%;background:#6366f1;height:6px;border-radius:4px"></div></div></td></tr>`;
      }).join('');
    }
  },

  _renderCharts(s) {
    Object.values(State.charts).forEach(c => { try { c.destroy(); } catch {} });
    State.charts = {};
    if (typeof Chart === 'undefined') return;

    const pie = $('pie-chart');
    if (pie) {
      State.charts.pie = new Chart(pie, {
        type: 'doughnut',
        data: { labels:['Matched Exact','Mismatched','Missing','Extra'], datasets:[{ data:[s.matchedExact||s.matched, s.mismatched||s.withDifferences||0, s.missingInVendor, s.extraInVendor], backgroundColor:['#10b981','#f59e0b','#ef4444','#8b5cf6'], borderWidth:2, borderColor:'#fff' }] },
        options: { responsive:true, plugins:{ legend:{ position:'bottom', labels:{ font:{ size:11 }, padding:12 } } } },
      });
    }

    const bar = $('bar-chart');
    if (bar && s.topDiffColumns?.length) {
      State.charts.bar = new Chart(bar, {
        type: 'bar',
        data: { labels:s.topDiffColumns.map(d=>d.column), datasets:[{ label:'Diff Count', data:s.topDiffColumns.map(d=>d.count), backgroundColor:'#6366f1', borderRadius:5 }] },
        options: { responsive:true, plugins:{ legend:{ display:false } }, scales:{ y:{ beginAtZero:true } } },
      });
    }
  },

  _renderRecommendations(s) {
    const el = $('recommendations-list'); if (!el) return;
    const rate = s.totalInternal > 0 ? Math.round((s.matched||0)/s.totalInternal*100) : 0;
    const recs = [];
    if (rate < 80)              recs.push({t:'error',   m:`Low match rate (${rate}%). Verify key column in Configure.`});
    if (s.missingInVendor > 0)  recs.push({t:'warning', m:`${s.missingInVendor.toLocaleString()} internal records missing from vendor.`});
    if (s.extraInVendor > 0)    recs.push({t:'info',    m:`${s.extraInVendor.toLocaleString()} vendor records have no internal match.`});
    if ((s.mismatched||s.withDifferences||0) > 0) recs.push({t:'warning', m:`${(s.mismatched||s.withDifferences||0).toLocaleString()} matched records have field differences.`});
    if ((s.duplicatesInternal||0)+(s.duplicatesVendor||0) > 0) recs.push({t:'warning', m:`Duplicate keys: ${s.duplicatesInternal||0} internal, ${s.duplicatesVendor||0} vendor.`});
    if (!recs.length) recs.push({t:'success', m:'Excellent result — no critical issues found.'});
    const BG={error:'#fee2e2',warning:'#fef3c7',info:'#dbeafe',success:'#dcfce7'};
    const FG={error:'#991b1b',warning:'#92400e',info:'#1e40af',success:'#166534'};
    const IC={error:'ti-alert-circle',warning:'ti-alert-triangle',info:'ti-info-circle',success:'ti-check-circle'};
    el.innerHTML = recs.map(r=>`<div style="display:flex;gap:10px;padding:12px;background:${BG[r.t]};border-radius:8px;margin-bottom:8px"><i class="ti ${IC[r.t]}" style="color:${FG[r.t]};flex-shrink:0;margin-top:1px"></i><span style="color:${FG[r.t]};font-size:13px">${r.m}</span></div>`).join('');
  },

  /* ── DETAIL TABLE ───────────────────────────────────────────────────────── */
  async loadDetailPage(page) {
    if (page != null) State.pagination.detail.page = page;
    if (!State.comparisonResult) return;
    const p  = State.pagination.detail;
    const ps = parseInt($('detail-page-size')?.value || '100');
    const q  = $('detail-search')?.value || '';
    const st = $('detail-status-filter')?.value || '';
    try {
      const data = await API.get(`/comparison/results?section=detail&page=${p.page}&pageSize=${ps}${q?'&search='+encodeURIComponent(q):''}${st?'&status='+st:''}`);
      const rows = data.rows || [], total = data.total || 0, cols = data.columns || [];
      const tbody = $('detail-tbody');
      if (tbody) {
        const thead = tbody.closest('table')?.querySelector('thead tr');
        if (thead && cols.length) thead.innerHTML = cols.map(c=>`<th>${_esc(c)}</th>`).join('') + '<th>Status</th><th>Diffs</th>';
        tbody.innerHTML = rows.map(r => {
          const st2 = r._status || 'matched';
          const badge = {matched:'<span class="badge badge-match">Matched</span>',mismatch:'<span class="badge badge-warn">Mismatch</span>',missing:'<span class="badge badge-diff">Missing</span>',extra:'<span class="badge badge-extra">Extra</span>'}[st2]||'';
          return `<tr class="row-${st2}">${cols.map(c=>`<td>${_esc(String(r[c]??''))}</td>`).join('')}<td>${badge}</td><td>${r._diffCount?`<code style="font-size:11px;color:#6366f1">${r._diffCount}</code>`:''}</td></tr>`;
        }).join('');
      }
      const pages = Math.ceil(total/(ps||100))||1;
      _text('detail-page-info', `Page ${p.page}/${pages} · ${total.toLocaleString()} records`);
      _disabled('detail-prev-btn', p.page <= 1);
      _disabled('detail-next-btn', p.page >= pages);
    } catch {}
  },

  /* BUG-FIX: detailSearch is called with a value arg from oninput; use _debounce properly */
  detailSearch: _debounce(function(_val) { App.loadDetailPage(1); }, 400),

  detailChangePage(dir) {
    State.pagination.detail.page = Math.max(1, State.pagination.detail.page + dir);
    this.loadDetailPage();
  },

  /* ── SKU TABLE ──────────────────────────────────────────────────────────── */
  async loadSkuPage(page) {
    if (page != null) State.pagination.sku.page = page;
    if (!State.comparisonResult) return;
    const p  = State.pagination.sku;
    const q  = $('sku-search')?.value || '';
    const st = $('sku-status-filter')?.value || '';
    try {
      const data = await API.get(`/comparison/results?section=detail&page=${p.page}&pageSize=${p.pageSize}${q?'&search='+encodeURIComponent(q):''}${st?'&status='+st:''}`);
      const s  = State.comparisonResult?.summary;
      const mEl = $('sku-metrics');
      if (mEl && s) mEl.innerHTML = [
        {label:'Missing',   val:s.missingInVendor,                          color:'#ef4444'},
        {label:'Extra',     val:s.extraInVendor,                            color:'#f59e0b'},
        {label:'Mismatched',val:s.mismatched||s.withDifferences||0,         color:'#8b5cf6'},
        {label:'Dup Keys',  val:(s.duplicatesInternal||0)+(s.duplicatesVendor||0), color:'#6b7280'},
      ].map(m=>`<div class="metric metric-top" style="border-top-color:${m.color}"><div class="metric-val" style="color:${m.color}">${(m.val||0).toLocaleString()}</div><div class="metric-lbl">${m.label}</div></div>`).join('');

      const tbody = $('sku-tbody');
      if (tbody) tbody.innerHTML = (data.rows||[]).map(r => {
        const st2 = r._status || 'matched';
        const badge={matched:'<span class="badge badge-match">Matched</span>',mismatch:'<span class="badge badge-warn">Mismatch</span>',missing:'<span class="badge badge-diff">Missing</span>',extra:'<span class="badge badge-extra">Extra</span>'}[st2]||'';
        const key = r._key || (Object.values(r).find(v => v && String(v).length < 80 && !String(v).startsWith('_'))) || '—';
        return `<tr class="row-${st2}"><td>${badge}</td><td><code style="font-size:12px">${_esc(String(key))}</code></td><td>${st2==='missing'?'Internal Only':st2==='extra'?'Vendor Only':'Both'}</td><td>${r._diffCount||''}</td></tr>`;
      }).join('');

      const pages = Math.ceil((data.total||0)/p.pageSize)||1;
      _text('sku-page-info', `${(data.total||0).toLocaleString()} records · Page ${p.page}/${pages}`);
      if (page === 1) this._renderDuplicates();
    } catch {}
  },

  async _renderDuplicates() {
    try {
      const data = await API.get('/comparison/results?section=duplicates&page=1&pageSize=50');
      const tbody = $('dup-tbody'); if (!tbody) return;
      const rows = data.rows || [];
      tbody.innerHTML = rows.length
        ? rows.map(d=>`<tr><td><span class="badge badge-${d.source==='Internal'?'blue':'purple'}">${_esc(d.source)}</span></td><td><code style="font-size:12px">${_esc(d.key)}</code></td><td><strong>${d.count}</strong></td></tr>`).join('')
        : '<tr><td colspan="3" style="text-align:center;color:#9ca3af;padding:16px">No duplicates detected</td></tr>';
    } catch {}
  },

  skuChangePage(dir) { State.pagination.sku.page = Math.max(1, State.pagination.sku.page + dir); this.loadSkuPage(); },

  /* ── DIFF TABLE ─────────────────────────────────────────────────────────── */
  async loadDiffPage(page) {
    if (page != null) State.pagination.diff.page = page;
    if (!State.comparisonResult) return;
    const p   = State.pagination.diff;
    const col = $('diff-col-filter')?.value || '';
    try {
      const data = await API.get(`/comparison/results?section=diffs&page=${p.page}&pageSize=50${col?'&col='+encodeURIComponent(col):''}`);
      const tbody = $('diff-tbody');
      if (tbody) tbody.innerHTML = (data.rows||[]).map(r=>`<tr><td><code style="font-size:12px">${_esc(String(r.key??''))}</code></td><td><code style="font-size:11px;color:#6366f1">${_esc(String(r.column??''))}</code></td><td class="diff-cell-old">${_esc(String(r.internalValue??''))}</td><td class="diff-cell-new">${_esc(String(r.vendorValue??''))}</td></tr>`).join('');

      const sel = $('diff-col-filter');
      if (sel && data.availableColumns?.length && sel.options.length <= 1) {
        data.availableColumns.forEach(c => { const o = document.createElement('option'); o.value=c; o.textContent=c; sel.appendChild(o); });
      }

      const mEl = $('diff-metrics');
      if (mEl && data.summary) {
        const ds = data.summary;
        mEl.innerHTML = [
          {label:'Total Diffs',   val:ds.total,   color:'#ef4444'},
          {label:'Cols Affected', val:ds.columns, color:'#8b5cf6'},
          {label:'Rows Affected', val:ds.records, color:'#f59e0b'},
          {label:'Diff Rate',     val:(ds.diffRate||0)+'%', color:'#6366f1'},
        ].map(m=>`<div class="metric metric-top" style="border-top-color:${m.color}"><div class="metric-val" style="color:${m.color}">${(m.val||0).toLocaleString()}</div><div class="metric-lbl">${m.label}</div></div>`).join('');
      }

      const pages = Math.ceil((data.total||0)/50)||1;
      _text('diff-page-info', `${(data.total||0).toLocaleString()} differences · Page ${p.page}/${pages}`);
    } catch {}
  },

  diffChangePage(dir) { State.pagination.diff.page = Math.max(1, State.pagination.diff.page + dir); this.loadDiffPage(); },

  /* ── CATEGORY ANALYSIS ──────────────────────────────────────────────────── */
  /* BUG-FIX: always repopulate (removed stale-cache guard) */
  _populateCatBrand() {
    const iCols = State.files.internal?.columns || [];
    const vCols = State.files.vendor?.columns   || [];
    const fillSel = (id, cols) => {
      const e = $(id); if (!e) return;
      const cur = e.value;
      e.innerHTML = '<option value="">— select —</option>' + cols.map(c=>`<option${c===cur?' selected':''}>${_esc(c)}</option>`).join('');
    };
    fillSel('cat-int-col', iCols); fillSel('cat-vnd-col', vCols);
    const fillMulti = (id, cols) => {
      const e = $(id); if (!e) return;
      const prevSel = [...e.selectedOptions].map(o => o.value);
      e.innerHTML = cols.map(c=>`<option${prevSel.includes(c)?' selected':''}>${_esc(c)}</option>`).join('');
    };
    fillMulti('brand-int-cols', iCols); fillMulti('brand-vnd-cols', vCols);
  },

  async runCategoryAnalysis() {
    const iCol = $('cat-int-col')?.value, vCol = $('cat-vnd-col')?.value;
    if (!iCol || !vCol) { Toast.warning('Select both internal and vendor columns'); return; }
    if (!State.files.internal || !State.files.vendor) { Toast.warning('Load both files first'); return; }
    Progress.show('Running category analysis…', 40);
    try {
      const data = await API.post('/comparison/brand-analysis', { column: iCol, vendorColumn: vCol, type: 'category' });
      Progress.hide();
      _show('cat-results', true);
      const tbody = $('cat-tbody');
      if (tbody) tbody.innerHTML = (data.results||[]).map(r => {
        const diff = (r.internalCount||0) - (r.vendorCount||0);
        const diffBadge = diff===0 ? '<span class="badge badge-match">Match</span>' : `<span class="badge badge-${diff>0?'diff':'extra'}">${diff>0?'+':''}${diff}</span>`;
        return `<tr><td><strong>${_esc(String(r.value||''))}</strong></td><td>${(r.internalCount||0).toLocaleString()}</td><td>${(r.vendorCount||0).toLocaleString()}</td><td>${diffBadge}</td><td><span class="badge badge-${(r.matchRate||0)>=90?'match':'warn'}">${r.matchRate||0}%</span></td></tr>`;
      }).join('');
      Toast.success(`${(data.results||[]).length} categories analysed`);
    } catch (err) { Progress.hide(); Toast.error('Category analysis failed: ' + err.message); }
  },

  exportCategoryAnalysis() { this.exportSection('diffs', 'csv'); },

  /* ── BRAND ANALYSIS ─────────────────────────────────────────────────────── */
  async runBrandAnalysis() {
    const brands = ($('brand-input')?.value||'').split('\n').map(s=>s.trim()).filter(Boolean);
    if (!brands.length) { Toast.warning('Enter at least one brand name'); return; }
    if (!State.files.internal || !State.files.vendor) { Toast.warning('Load both files first'); return; }
    const iCols = [...($('brand-int-cols')?.selectedOptions||[])].map(o=>o.value);
    const vCols = [...($('brand-vnd-cols')?.selectedOptions||[])].map(o=>o.value);
    if (!iCols.length) { Toast.warning('Select at least one internal column to search'); return; }
    Progress.show('Running brand analysis…', 40);
    try {
      const data = await API.post('/comparison/brand-analysis', { brands, internalColumns:iCols, vendorColumns:vCols, type:'brand' });
      Progress.hide();
      _show('brand-results', true);
      const tbody = $('brand-tbody');
      if (tbody) tbody.innerHTML = (data.results||[]).map(r => {
        const rate = r.matchPct||r.matchRate||0, diff=(r.internalCount||0)-(r.vendorCount||0);
        return `<tr><td><strong>${_esc(String(r.brand||r.value||''))}</strong></td><td>${(r.internalCount||0).toLocaleString()}</td><td>${(r.vendorCount||0).toLocaleString()}</td><td>${diff>=0?'+':''}<strong style="color:${diff>=0?'var(--green)':'var(--red)'}">${diff}</strong></td><td><div style="display:flex;align-items:center;gap:8px"><div style="flex:1;background:#e5e7eb;border-radius:4px;height:6px;min-width:60px"><div style="width:${Math.min(100,rate)}%;background:${rate>=90?'var(--green)':rate>=70?'var(--amber)':'var(--red)'};height:6px;border-radius:4px"></div></div><span style="font-size:11px;width:32px;text-align:right">${rate}%</span></div></td></tr>`;
      }).join('');
      Toast.success(`${brands.length} brands analysed`);
    } catch (err) { Progress.hide(); Toast.error('Brand analysis failed: ' + err.message); }
  },

  exportBrandResults() { this.exportSection('matched', 'csv'); },

  /* ── EXPORT ─────────────────────────────────────────────────────────────── */
  _updateExportView() {
    const has = !!State.comparisonResult;
    _show('export-no-results', !has);
    _show('export-ready',      has);
  },

  async exportSection(section, format) {
    if (!State.comparisonResult) { Toast.warning('Run a comparison first'); return; }
    Progress.show(`Generating ${section} ${format.toUpperCase()}…`, 50);
    try {
      const data = await API.post('/export/generate', { section, format });
      Progress.hide();
      if (data.filename) { _triggerDownload(`/api/export/download/${data.filename}`, data.filename); Toast.success('Download starting…'); }
    } catch (err) { Progress.hide(); Toast.error('Export failed: ' + err.message); }
  },

  async exportFull(format) {
    if (!State.comparisonResult) { Toast.warning('Run a comparison first'); return; }
    Progress.show(`Generating ${format.toUpperCase()} report…`, 20);
    try {
      const data = await API.post('/export/generate', { section:'all', format });
      Progress.hide();
      if (data.filename) { _triggerDownload(`/api/export/download/${data.filename}`, data.filename); Toast.success('Report ready — downloading…'); this.loadReportList(); }
    } catch (err) { Progress.hide(); Toast.error('Export failed: ' + err.message); }
  },

  quickExport() {
    if (!State.comparisonResult) { Toast.warning('Run a comparison first'); return; }
    this.exportFull('excel');
  },

  async loadReportList() {
    try {
      const data = await API.get('/export/list');
      const reports = data.reports || [];
      const tbody   = $('reports-tbody');
      const emptyEl = $('reports-empty');
      if (emptyEl) emptyEl.style.display = reports.length ? 'none' : '';
      if (!tbody) return;
      tbody.innerHTML = reports.map(r => {
        const icon  = r.format==='pdf'?'ti-file-type-pdf':r.format==='csv'?'ti-file-type-csv':'ti-file-spreadsheet';
        const color = r.format==='pdf'?'var(--red)':r.format==='csv'?'var(--amber)':'var(--green)';
        const fn    = _esc(r.filename);
        return `<tr>
          <td><i class="ti ${icon}" style="color:${color}"></i> ${fn}</td>
          <td><span class="badge badge-gray">${r.type||''}</span></td>
          <td>${_size(r.size)}</td>
          <td style="font-size:12px">${new Date(r.created).toLocaleString()}</td>
          <td>
            <button class="btn btn-sm btn-primary" onclick="_triggerDownload('/api/export/download/${fn}','${fn}')" title="Download"><i class="ti ti-download"></i></button>
            <button class="btn btn-sm btn-ghost"   onclick="App._delReport('${fn}')" title="Delete"><i class="ti ti-trash" style="color:var(--red)"></i></button>
          </td>
        </tr>`;
      }).join('');
    } catch (err) { Toast.error('Failed to load reports: ' + err.message); }
  },

  async _delReport(f) {
    if (!confirm('Delete ' + f + '?')) return;
    try { await API.del('/export/' + encodeURIComponent(f)); Toast.success('Deleted'); this.loadReportList(); }
    catch (err) { Toast.error(err.message); }
  },

  /* ── PERFORMANCE ────────────────────────────────────────────────────────── */
  _renderPerformance() {
    const s = State.comparisonResult?.summary;
    const mEl = $('perf-metrics');
    if (!mEl) return;
    const dur  = s?.durationMs  ? (s.durationMs/1000).toFixed(2)+'s'      : '—';
    const rps  = s?.rowsPerSec  ? s.rowsPerSec.toLocaleString()+' r/s'    : '—';
    const rows = s?.totalInternal ? ((s.totalInternal+s.totalVendor)||0).toLocaleString() : '—';
    const chnk = s?.chunksUsed || '—';
    mEl.innerHTML = [
      {label:'Last Run Time',  val:dur,  color:'var(--blue)'  },
      {label:'Throughput',     val:rps,  color:'var(--green)' },
      {label:'Rows Processed', val:rows, color:'var(--purple)'},
      {label:'Chunks Used',    val:chnk, color:'var(--amber)' },
    ].map(m=>`<div class="metric metric-top" style="border-top-color:${m.color}"><div class="metric-val" style="color:${m.color};font-size:22px">${m.val}</div><div class="metric-lbl">${m.label}</div></div>`).join('');

    const tl = $('perf-timeline');
    if (tl && s) {
      const STEPS = ['Filtering','Indexing','Matching','Extra Detection','Analytics'];
      const PCTS  = [5, 10, 55, 10, 20];
      tl.innerHTML = STEPS.map((step, i) => {
        const ms = s.durationMs ? Math.round(s.durationMs * PCTS[i] / 100) : '—';
        return `<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px"><div style="font-size:12px;width:130px;color:#374151">${step}</div><div style="flex:1;background:#e5e7eb;border-radius:4px;height:8px"><div style="width:${PCTS[i]}%;background:var(--blue);height:8px;border-radius:4px"></div></div><div style="font-size:11px;color:#6b7280;width:60px;text-align:right">${ms}ms</div></div>`;
      }).join('');
    }
  },

  /* ── ACTIVITY LOG ───────────────────────────────────────────────────────── */
  toggleActivityLog() {
    const p = $('activity-panel');
    if (!p) return;
    const open = p.style.display === 'flex';
    p.style.display = open ? 'none' : 'flex';
    if (!open) {
      Activity.unread = 0;
      const b = $('activity-unread'); if (b) b.style.display = 'none';
    }
  },

  async clearActivityLog() {
    try { await API.del('/activity/logs'); } catch {}
    const l = $('activity-log-list'); if (l) l.innerHTML = '';
    Toast.success('Activity log cleared');
  },

  /* ── RESET SESSION ──────────────────────────────────────────────────────── */
  async resetSession() {
    if (!confirm('Reset session? All data will be cleared.')) return;
    try { await API.del('/files/session/' + State.sessionId); } catch {}

    State.files           = { internal:null, vendor:null };
    State.mappings        = [];
    State.filterRules     = [];
    State.comparisonResult= null;
    State.jobId           = null;
    State.azure           = { connected:false, accountName:null, container:null, prefix:'', cache:{}, allFiles:[], filteredFiles:[], sortKey:'name', sortAsc:true, selectedBlob:null, files:{internal:null,vendor:null}, searchQuery:'' };

    if (State.jobPollInterval) clearInterval(State.jobPollInterval);
    Object.values(State.charts).forEach(c => { try { c.destroy(); } catch {} });
    State.charts = {};

    ['int-file-info','vnd-file-info'].forEach(id => { const e=$(id); if(e){e.style.display='none';e.innerHTML='';} });
    _badge('int-badge','Not loaded','badge-gray');
    _badge('vnd-badge','Not loaded','badge-gray');
    this._updateStatus();
    this.chooseSource(null);
    this.showView('upload');
    Toast.info('Session reset — ready for a new comparison.');
  },

  /* ── SIDEBAR STATUS ─────────────────────────────────────────────────────── */
  _updateStatus() {
    _dot('sb-azure-dot','sb-azure-status', State.azure.connected,    'Azure: Connected',   'Azure: Not Connected');
    _dot('sb-int-dot',  'sb-int-status',   !!State.files.internal,   'Internal: Loaded',   'Internal: No file');
    _dot('sb-vnd-dot',  'sb-vnd-status',   !!State.files.vendor,     'Vendor: Loaded',     'Vendor: No file');
    _dot('sb-cmp-dot',  'sb-cmp-status',   !!State.comparisonResult, 'Comparison: Done',   'Comparison: Pending');
  },

  /* ═══════════════════════════════════════════════════════════════════════════
     AZURE STORAGE BROWSER
  ═══════════════════════════════════════════════════════════════════════════ */

  async azureConnect() {
    const connStr = $('az-conn-str')?.value?.trim();
    const accName = $('az-account-name')?.value?.trim();
    const accKey  = $('az-account-key')?.value?.trim();

    if (!connStr && (!accName || !accKey)) {
      Toast.warning('Provide a connection string or account name + key'); return;
    }

    const btn = $('az-connect-btn');
    if (btn) { btn.disabled=true; btn.innerHTML='<i class="ti ti-loader spin"></i> Connecting…'; }
    const errEl = $('az-connect-error');
    if (errEl) errEl.style.display='none';

    try {
      const result = await API.post('/azure/connect', { connectionString:connStr, accountName:accName, accountKey:accKey });
      State.azure.connected   = true;
      State.azure.accountName = result.accountName || accName || 'Unknown';

      _show('az-creds-form', false);
      /* BUG-FIX: az-info-bar needs display:flex not '' */
      _showFlex('az-info-bar', true);
      _show('az-disconnect-btn', true);
      _show('az-browser-panel', true);
      _show('az-select-panel',  true);
      _badge('az-status-badge', 'Connected', 'badge-match');
      _text('az-info-account', State.azure.accountName);

      this._updateStatus();
      Toast.success(`Connected to Azure: ${State.azure.accountName}`);
      await this.azureRefresh();
    } catch (err) {
      if (btn) { btn.disabled=false; btn.innerHTML='<i class="ti ti-plug"></i> Connect to Azure'; }
      if (errEl) {
        errEl.style.display='block';
        errEl.innerHTML=`<span style="color:#ef4444;font-size:12px;background:#fee2e2;padding:5px 9px;border-radius:5px;display:inline-flex;gap:6px;align-items:center"><i class="ti ti-alert-circle"></i>${_esc(err.message)}</span>`;
      }
      Toast.error('Azure connection failed: ' + err.message);
    }
  },

  async azureDisconnect() {
    if (!confirm('Disconnect from Azure Storage?')) return;
    try { await API.post('/azure/disconnect', {}); } catch {}
    State.azure = { connected:false, accountName:null, container:null, prefix:'', cache:{}, allFiles:[], filteredFiles:[], sortKey:'name', sortAsc:true, selectedBlob:null, files:{internal:null,vendor:null}, searchQuery:'' };

    _show('az-creds-form', true);
    const ib = $('az-info-bar'); if (ib) ib.style.display='none';
    const cb = $('az-connect-btn'); if(cb){cb.style.display='';cb.disabled=false;cb.innerHTML='<i class="ti ti-plug"></i> Connect to Azure';}
    _show('az-disconnect-btn', false);
    _show('az-browser-panel', false);
    _show('az-select-panel',  false);
    _badge('az-status-badge','Disconnected','badge-gray');
    const sel=$('az-container-select'); if(sel) sel.innerHTML='<option value="">— select a container —</option>';
    this._azResetTree(); this._azClearFileList(); this._azUpdateCards();
    this._updateStatus();
    Toast.info('Disconnected from Azure');
  },

  async azureRefresh() {
    try {
      const data = await API.get('/azure/containers');
      State.azure.containers = data.containers || [];
      const sel = $('az-container-select');
      if (sel) {
        sel.innerHTML = '<option value="">— select a container —</option>' +
          State.azure.containers.map(c=>`<option value="${_esc(c.name)}">${_esc(c.name)}${c.publicAccess?' ✦':''}</option>`).join('');
      }
      const cnt = State.azure.containers.length;
      Toast.info(`${cnt} container${cnt!==1?'s':''} found`);
    } catch (err) { Toast.error('Failed to list containers: ' + err.message); }
  },

  async azureSelectContainer() {
    const container = $('az-container-select')?.value;
    if (!container) return;
    State.azure.container   = container;
    State.azure.prefix      = '';
    State.azure.cache       = {};
    State.azure.searchQuery = '';
    _text('az-info-container', container);
    _text('az-info-path',      'root');
    _show('az-search-bar', false);
    this._azUpdateBreadcrumb();
    this._azResetTree();
    this._azClearFileList();
    await this._azLoadFolder('', true);
  },

  /* BUG-FIX: alias for HTML button "onclick=App.azureSearch()" */
  azureSearch()    { this.azureToggleSearch(); },
  azureListBlobs() { return this.azureSelectContainer(); },

  async _azLoadFolder(prefix, intoTree) {
    const container = State.azure.container; if (!container) return;
    if (State.azure.cache[prefix]) {
      this._azRenderFolder(prefix, State.azure.cache[prefix], intoTree);
      return;
    }
    const treeEl = $('az-folder-tree'), rowsEl = $('az-file-rows');
    if (intoTree && treeEl) treeEl.innerHTML = '<div style="padding:20px;text-align:center;color:#6b7280;font-size:12px"><i class="ti ti-loader spin"></i> Loading…</div>';
    if (rowsEl) rowsEl.innerHTML = '<div style="padding:32px;text-align:center;color:#6b7280;font-size:12px"><i class="ti ti-loader spin"></i> Loading…</div>';
    try {
      const data = await API.get(`/azure/folders/${encodeURIComponent(container)}?prefix=${encodeURIComponent(prefix)}`);
      State.azure.cache[prefix] = data;
      this._azRenderFolder(prefix, data, intoTree);
    } catch (err) {
      if (treeEl) treeEl.innerHTML = `<div style="padding:12px;color:#ef4444;font-size:12px">${_esc(err.message)}</div>`;
      Toast.error('Failed to load folder: ' + err.message);
    }
  },

  _azRenderFolder(prefix, data, intoTree) {
    const { folders=[], files=[] } = data;
    if (prefix === State.azure.prefix) {
      State.azure.allFiles      = files;
      State.azure.filteredFiles = State.azure.searchQuery
        ? files.filter(f => (f.shortName||f.name||'').toLowerCase().includes(State.azure.searchQuery.toLowerCase()))
        : [...files];
      this._azRenderFileList();
    }
    if (intoTree) this._azRenderTree(folders, prefix);
  },

  _azRenderTree(folders, prefix) {
    const treeEl = $('az-folder-tree'); if (!treeEl) return;
    const rootActive = State.azure.prefix === '' ? 'az-tree-active' : '';
    let html = `<div class="az-tree-item ${rootActive}" onclick="App._azNav('')" style="padding:7px 8px;border-radius:6px;font-size:12px;display:flex;align-items:center;gap:7px;cursor:pointer;margin-bottom:2px;font-weight:600">
      <i class="ti ti-home-2" style="color:var(--purple);font-size:13px"></i><span style="flex:1">/ root</span>
    </div>`;
    folders.forEach(f => { html += this._azFolderNodeHTML(f); });
    treeEl.innerHTML = html || '<div style="color:#9ca3af;font-size:12px;padding:16px;text-align:center">No folders found</div>';
  },

  _azFolderNodeHTML(folder) {
    const isActive = State.azure.prefix === folder.path;
    return `<div class="az-tree-folder" data-pfx="${_esc(folder.path)}" style="margin-bottom:2px">
      <div class="az-tree-item ${isActive?'az-tree-active':''}" onclick="App._azNav('${_esc(folder.path)}')" style="padding:6px 8px;border-radius:6px;font-size:12px;display:flex;align-items:center;gap:7px;cursor:pointer">
        <i class="ti ti-chevron-right" style="font-size:11px;color:#9ca3af;transition:transform .15s;flex-shrink:0"></i>
        <i class="ti ti-folder" style="color:#f59e0b;flex-shrink:0"></i>
        <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${_esc(folder.name)}">${_esc(folder.shortName||folder.name)}</span>
      </div>
      <div class="az-tree-children" style="display:none;padding-left:14px;border-left:2px solid #e5e7eb;margin:2px 0 2px 10px"></div>
    </div>`;
  },

  async _azNav(prefix) {
    State.azure.prefix      = prefix;
    State.azure.searchQuery = '';
    const si = $('az-search-input'); if (si) si.value='';
    _show('az-search-bar', false);
    _text('az-info-path', prefix || 'root');
    this._azUpdateBreadcrumb();

    document.querySelectorAll('.az-tree-item').forEach(e => e.classList.remove('az-tree-active'));
    const activeNode = prefix === ''
      ? document.querySelector('.az-tree-item')
      : document.querySelector(`.az-tree-folder[data-pfx="${CSS.escape(prefix)}"] .az-tree-item`);
    if (activeNode) activeNode.classList.add('az-tree-active');

    if (prefix) {
      const node = document.querySelector(`.az-tree-folder[data-pfx="${CSS.escape(prefix)}"]`);
      if (node) {
        const children = node.querySelector('.az-tree-children');
        const icon     = node.querySelector('.ti-chevron-right');
        if (children) children.style.display = children.style.display === 'block' ? 'none' : 'block';
        if (icon)     icon.style.transform   = (children?.style.display === 'block') ? 'rotate(90deg)' : '';
      }
    }

    const rowsEl = $('az-file-rows');
    if (rowsEl) rowsEl.innerHTML='<div style="padding:32px;text-align:center;color:#6b7280;font-size:12px"><i class="ti ti-loader spin"></i> Loading…</div>';
    await this._azLoadFolder(prefix, false);

    if (prefix && State.azure.cache[prefix]) {
      const node      = document.querySelector(`.az-tree-folder[data-pfx="${CSS.escape(prefix)}"]`);
      const childrenEl= node?.querySelector('.az-tree-children');
      if (childrenEl && !childrenEl.innerHTML.trim()) {
        childrenEl.innerHTML = State.azure.cache[prefix].folders.map(f => this._azFolderNodeHTML(f)).join('');
      }
    }
  },

  _azUpdateBreadcrumb() {
    const el = $('az-breadcrumb'); if (!el) return;
    const prefix    = State.azure.prefix;
    const container = State.azure.container || '';
    const parts = prefix ? prefix.replace(/\/$/, '').split('/') : [];
    let built='', html=`<span onclick="App._azNav('')" style="cursor:pointer;color:var(--purple);font-weight:600"><i class="ti ti-home"></i> ${_esc(container)}</span>`;
    parts.forEach((p, i) => {
      built += (built?'/':'') + p;
      const bp = built + '/';
      html += `<i class="ti ti-chevron-right" style="color:#9ca3af;font-size:10px"></i>`;
      html += i === parts.length-1
        ? `<strong><i class="ti ti-folder-open" style="color:#f59e0b"></i> ${_esc(p)}</strong>`
        : `<span onclick="App._azNav('${_esc(bp)}')" style="cursor:pointer;color:var(--purple)">${_esc(p)}</span>`;
    });
    el.style.display='flex';
    el.innerHTML=html;
  },

  _azResetTree() {
    const t=$('az-folder-tree');
    if(t) t.innerHTML='<div style="color:#9ca3af;font-size:12px;text-align:center;padding:28px"><i class="ti ti-folder-open" style="font-size:28px;display:block;margin-bottom:8px;opacity:.3"></i>Select a container to browse</div>';
    const bc=$('az-breadcrumb'); if(bc) bc.style.display='none';
  },

  _azClearFileList() {
    const rows=$('az-file-rows'), hdr=$('az-file-header'), cnt=$('az-file-count');
    if(rows) rows.innerHTML='<div style="padding:40px;text-align:center;color:#9ca3af;font-size:12px"><i class="ti ti-folder-open" style="font-size:32px;display:block;margin-bottom:8px;opacity:.3"></i>Select a folder to view files</div>';
    if(hdr) hdr.style.display='none';
    if(cnt) cnt.textContent='No folder selected';
    _show('az-preview-bar', false);
  },

  _azRenderFileList() {
    const files  = State.azure.filteredFiles || [];
    const rowsEl = $('az-file-rows'), hdrEl=$('az-file-header'), cntEl=$('az-file-count');
    /* BUG-FIX: az-sort-bar needs display:flex */
    const sortBar = $('az-sort-bar');
    if (sortBar) sortBar.style.display = 'flex';

    const sorted = [...files].sort((a, b) => {
      const k = State.azure.sortKey;
      const va = k==='size' ? (a.size||0) : k==='date' ? new Date(a.lastModified||0).getTime() : (a.shortName||a.name||'').toLowerCase();
      const vb = k==='size' ? (b.size||0) : k==='date' ? new Date(b.lastModified||0).getTime() : (b.shortName||b.name||'').toLowerCase();
      return State.azure.sortAsc ? (va>vb?1:va<vb?-1:0) : (va<vb?1:va>vb?-1:0);
    });

    ['name','size','date'].forEach(k => { const e=$(('sort-'+k+'-icon')); if(e) e.textContent=State.azure.sortKey===k?(State.azure.sortAsc?' ↑':' ↓'):''; });

    if (hdrEl) hdrEl.style.display = sorted.length ? 'grid' : 'none';
    if (cntEl) cntEl.textContent = `${sorted.length} file${sorted.length!==1?'s':''}${State.azure.searchQuery?' (filtered)':''}`;

    if (!sorted.length) {
      if (rowsEl) rowsEl.innerHTML=`<div style="padding:32px;text-align:center;color:#9ca3af;font-size:12px"><i class="ti ti-${State.azure.searchQuery?'search-off':'inbox'}" style="font-size:28px;display:block;margin-bottom:8px;opacity:.3"></i>${State.azure.searchQuery?'No files match your search':'No files in this folder'}</div>`;
      return;
    }
    if (rowsEl) rowsEl.innerHTML = sorted.map(f => this._azFileRowHTML(f)).join('');
  },

  _azFileRowHTML(f) {
    const SUPPORTED = ['csv','xlsx','xls','xlsm','tsv','txt','zip'];
    const ext = (f.ext||'').replace('.','').toLowerCase();
    const ok  = SUPPORTED.includes(ext) || f.supported === true || (f.supported !== false && ext === '');
    const icon = ext==='zip'?'ti-file-zip':['xlsx','xls','xlsm'].includes(ext)?'ti-file-spreadsheet':['csv','tsv'].includes(ext)?'ti-file-type-csv':'ti-file-text';
    const isInt = State.azure.files?.internal?.name === f.name;
    const isVnd = State.azure.files?.vendor?.name   === f.name;
    const isSel = State.azure.selectedBlob?.name    === f.name;
    const mod   = f.lastModified ? new Date(f.lastModified).toLocaleDateString() : '—';
    /* BUG-FIX: encode JSON cleanly to avoid XSS and JS parse errors */
    const safeJson = JSON.stringify(JSON.stringify(f));

    return `<div class="az-file-row${isSel?' az-row-selected':''}" data-name="${_esc(f.name)}"
      onclick="App._azSelectFile(this,${safeJson})"
      style="display:grid;grid-template-columns:1fr 80px 110px 90px;gap:8px;padding:7px 12px;border-bottom:1px solid #f3f4f6;cursor:${ok?'pointer':'default'};opacity:${ok?1:0.5};${isSel?'background:#eff6ff;border-left:3px solid var(--blue);':''}align-items:center;transition:background .1s">
      <div style="display:flex;align-items:center;gap:8px;overflow:hidden">
        <i class="ti ${icon}" style="color:${ok?'#6366f1':'#9ca3af'};font-size:15px;flex-shrink:0"></i>
        <span style="font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:${ok?'500':'400'}" title="${_esc(f.name)}">${_esc(f.shortName||f.name)}</span>
        ${isInt?'<span style="background:#dbeafe;color:#1e40af;font-size:9px;padding:1px 5px;border-radius:99px;white-space:nowrap;flex-shrink:0">INT</span>':''}
        ${isVnd?'<span style="background:#ede9fe;color:#4c1d95;font-size:9px;padding:1px 5px;border-radius:99px;white-space:nowrap;flex-shrink:0">VND</span>':''}
        ${!ok?'<span style="background:#f3f4f6;color:#9ca3af;font-size:9px;padding:1px 5px;border-radius:99px;white-space:nowrap;flex-shrink:0">unsupported</span>':''}
      </div>
      <div style="font-size:11px;color:#6b7280;text-align:right">${_size(f.size)}</div>
      <div style="font-size:11px;color:#6b7280">${mod}</div>
      <div style="display:flex;gap:4px">
        ${ok?`
          <button onclick="event.stopPropagation();App._azQuickSet('internal',${safeJson})" title="Set as Internal" style="background:#1d4ed8;color:#fff;border:none;border-radius:4px;padding:2px 6px;font-size:10px;cursor:pointer;font-weight:700">INT</button>
          <button onclick="event.stopPropagation();App._azQuickSet('vendor',${safeJson})"   title="Set as Vendor"   style="background:#7c3aed;color:#fff;border:none;border-radius:4px;padding:2px 6px;font-size:10px;cursor:pointer;font-weight:700">VND</button>
        `:''}
      </div>
    </div>`;
  },

  _azSelectFile(el, fileJson) {
    document.querySelectorAll('.az-file-row').forEach(r => { r.style.background=''; r.style.borderLeft=''; r.classList.remove('az-row-selected'); });
    el.style.background='#eff6ff'; el.style.borderLeft='3px solid var(--blue)'; el.classList.add('az-row-selected');
    try { State.azure.selectedBlob = JSON.parse(fileJson); } catch { return; }
    this._azShowPreview(State.azure.selectedBlob);
  },

  _azQuickSet(side, fileJson) {
    try {
      const f = JSON.parse(fileJson);
      State.azure.selectedBlob = f;
      this._azShowPreview(f);
      this.azureSetSide(side);
    } catch (err) { Toast.error('Could not set file: ' + err.message); }
  },

  _azShowPreview(f) {
    _show('az-preview-bar', true);
    _text('az-preview-name',     f.shortName || f.name || '');
    _text('az-preview-path',     f.name || '');
    _text('az-preview-size',     _size(f.size));
    _text('az-preview-modified', f.lastModified ? new Date(f.lastModified).toLocaleString() : '—');
  },

  /* BUG-FIX: validate file type before assigning; container from State.azure.container */
  azureSetSide(side) {
    const f = State.azure.selectedBlob;
    if (!f) { Toast.warning('Select a file first'); return; }
    const SUPPORTED = ['csv','xlsx','xls','xlsm','tsv','txt','zip'];
    const ext = (f.ext||'').replace('.','').toLowerCase();
    if (f.supported === false || (ext && !SUPPORTED.includes(ext))) {
      Toast.error(`Unsupported file type: .${ext}`); return;
    }
    State.azure.files[side] = { ...f, container: f.container || State.azure.container };
    this._azUpdateCards();
    Toast.success(`${side==='internal'?'Internal':'Vendor'} set: ${f.shortName||f.name}`);
    this._azRenderFileList();
  },

  azureClearSide(side) {
    State.azure.files[side] = null;
    this._azUpdateCards();
    this._azRenderFileList();
    _disabled('az-load-btn', true);
    _disabled('az-next-btn', true);
  },

  _azUpdateCards() {
    ['internal','vendor'].forEach(side => {
      const isInt = side==='internal', f=State.azure.files[side];
      _show(isInt?'az-int-card-empty':'az-vnd-card-empty', !f);
      _show(isInt?'az-int-card-filled':'az-vnd-card-filled', !!f);
      _badge(isInt?'az-int-badge':'az-vnd-badge', f?'Selected':'Not set', f?(isInt?'badge-blue':'badge-purple'):'badge-gray');
      if (f) {
        _text(isInt?'az-int-card-name':'az-vnd-card-name', f.shortName||f.name||'');
        _text(isInt?'az-int-card-meta':'az-vnd-card-meta', `${_size(f.size)} · ${(f.ext||'').replace('.','').toUpperCase()||'?'}${f.lastModified?' · '+new Date(f.lastModified).toLocaleDateString():''}`);
        _text(isInt?'az-int-card-path':'az-vnd-card-path', `${f.container||State.azure.container||''}/${f.name}`);
      }
    });
    _disabled('az-load-btn', !(State.azure.files.internal && State.azure.files.vendor));
  },

  async azureLoadBoth() {
    if (!State.azure.files.internal || !State.azure.files.vendor) { Toast.warning('Set both internal and vendor files first'); return; }
    const prog = $('az-load-progress'), btn = $('az-load-btn');
    if (btn) btn.disabled=true;
    if (prog) { prog.style.display='block'; prog.innerHTML='<i class="ti ti-loader spin"></i> Downloading internal file…'; }
    try {
      const intData = await API.post('/azure/load', { container:State.azure.files.internal.container, blob:State.azure.files.internal.name, side:'internal' });
      if (prog) prog.innerHTML='<i class="ti ti-loader spin"></i> Downloading vendor file…';
      const vndData = await API.post('/azure/load', { container:State.azure.files.vendor.container, blob:State.azure.files.vendor.name, side:'vendor' });

      if (prog) prog.style.display='none';
      if (btn) btn.disabled=false;
      State.files.internal = { ...intData, filename:intData.filename||intData.originalName };
      State.files.vendor   = { ...vndData, filename:vndData.filename||vndData.originalName };
      this._showFileCard('internal', State.files.internal);
      this._showFileCard('vendor',   State.files.vendor);
      Toast.success('Both Azure files loaded — ready to map schema');
      this._updateStatus();
      /* BUG-FIX: _checkBoth enables az-next-btn */
      this._checkBoth();
    } catch (err) {
      if (btn) btn.disabled=false;
      if (prog) { prog.style.display='block'; prog.innerHTML=`<span style="color:#ef4444"><i class="ti ti-alert-circle"></i> ${_esc(err.message)}</span>`; }
      Toast.error('Azure load failed: ' + err.message);
    }
  },

  /* Azure search/sort/refresh */
  azureToggleSearch() {
    const bar=$('az-search-bar'); if(!bar) return;
    const showing = bar.style.display !== 'none' && bar.style.display !== '';
    if (showing) {
      bar.style.display='none';
      State.azure.searchQuery='';
      State.azure.filteredFiles=[...State.azure.allFiles];
      this._azRenderFileList();
    } else {
      bar.style.display='';
      $('az-search-input')?.focus();
    }
  },

  azureFilterFiles(q) {
    State.azure.searchQuery = q;
    const lo = q.toLowerCase();
    State.azure.filteredFiles = q ? State.azure.allFiles.filter(f=>(f.shortName||f.name||'').toLowerCase().includes(lo)) : [...State.azure.allFiles];
    this._azRenderFileList();
  },

  azureClearSearch() {
    const i=$('az-search-input'); if(i) i.value='';
    State.azure.searchQuery='';
    this.azureFilterFiles('');
    _show('az-search-bar', false);
  },

  azureSortFiles(key) {
    if (State.azure.sortKey === key) State.azure.sortAsc = !State.azure.sortAsc;
    else { State.azure.sortKey = key; State.azure.sortAsc = true; }
    this._azRenderFileList();
  },

  azureSort() { const s=$('az-sort-select'); if(s) this.azureSortFiles(s.value); },

  async azureRefreshFolder() {
    if (!State.azure.container) { await this.azureRefresh(); return; }
    delete State.azure.cache[State.azure.prefix];
    await this._azLoadFolder(State.azure.prefix, State.azure.prefix === '');
    Toast.info('Refreshed');
  },

}; /* end App */

/* ═══════════════════════════════════════════════════════════════════════════════
   DOM READY
═══════════════════════════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  initSession();
  initTabs();

  /* Sidebar navigation */
  document.querySelectorAll('.sb-item[data-view]').forEach(item => {
    item.addEventListener('click', () => App.showView(item.dataset.view));
  });

  /* Step bar navigation */
  document.querySelectorAll('.step[data-view]').forEach(step => {
    step.addEventListener('click', () => App.showView(step.dataset.view));
  });

  /* view-upload already has class="view active" in HTML — App.showView cleans up on nav */
  App._updateStatus();

  /* Azure panels: start hidden */
  _show('az-browser-panel', false);
  _show('az-select-panel',  false);
  _show('az-disconnect-btn',false);
  _show('az-preview-bar',   false);
  const ib = $('az-info-bar');    if (ib) ib.style.display = 'none';
  const ap = $('activity-panel'); if (ap) ap.style.display = 'none';

  /* Chunk size slider label */
  const slider = $('chunk-size-slider');
  if (slider) {
    slider.addEventListener('input', () => {
      const v = $('chunk-val');
      if (v) v.textContent = Number(slider.value).toLocaleString() + ' rows';
    });
  }
});
