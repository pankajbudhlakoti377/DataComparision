'use strict';

const XLSX = require('xlsx');
const fs   = require('fs-extra');
const path = require('path');
const PDFDocument = require('pdfkit');
const logger = require('../utils/logger');

class ReportGenerator {
  constructor() {
    this.dir = process.env.OUTPUT_DIR || './outputs';
    fs.ensureDirSync(this.dir);
  }

  // ─── Excel (multi-sheet) ────────────────────────────────────────────────
  async generateExcel(result, filename) {
    const wb = XLSX.utils.book_new();
    const { summary, matched = [], missingInVendor = [], extraInVendor = [], fieldDiffs = [], schemaComparison, analytics } = result;

    // Sheet 1: Summary
    const top = (analytics?.topDiffColumns || summary.topDiffColumns || []).slice(0, 12);
    const summaryAoa = [
      ['Data Comparison Report — Generated', new Date().toLocaleString()],
      [],
      ['METRIC', 'VALUE'],
      ['Internal Total Records',  summary.totalInternal],
      ['Vendor Total Records',    summary.totalVendor],
      ['Matched (exact)',         summary.matchedExact   || matched.filter(m => !m.hasDiffs).length],
      ['Matched (with diffs)',    summary.mismatched     || matched.filter(m => m.hasDiffs).length],
      ['Missing in Vendor',       summary.missingInVendor],
      ['Extra in Vendor',         summary.extraInVendor],
      ['Field-level Differences', summary.fieldDifferences || fieldDiffs.length],
      ['Match Rate',              summary.matchRate + '%'],
      ['Internal Duplicates',     summary.duplicatesInternal || 0],
      ['Vendor Duplicates',       summary.duplicatesVendor   || 0],
      ['Processing Time (ms)',    summary.durationMs || summary.elapsedMs || 0],
      [],
      ['TOP MISMATCHED COLUMNS'],
      ['Column', 'Diff Count', 'Diff %'],
      ...top.map(d => [d.column || d.col, d.count, (d.pct || 0) + '%'])
    ];
    const ws1 = XLSX.utils.aoa_to_sheet(summaryAoa);
    ws1['!cols'] = [{ wch: 30 }, { wch: 20 }];
    XLSX.utils.book_append_sheet(wb, ws1, 'Summary');

    // Sheet 2: Matched
    if (matched.length) {
      const rows = matched.slice(0, 100000).map(m => ({
        Key:         m.key,
        Status:      m.hasDiffs ? 'Mismatch' : 'Matched',
        DiffCount:   m.diffs?.length || 0,
        DiffColumns: m.diffs?.map(d => d.column).join(', ') || '',
        ...this._prefix('INT_', m.intRow),
        ...this._prefix('VND_', m.vndRow)
      }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), 'Matched');
    }

    // Sheet 3: Missing in Vendor
    if (missingInVendor.length) {
      const rows = missingInVendor.slice(0, 100000).map(m => ({ Key: m.key, Status: 'Missing in Vendor', ...m.intRow }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), 'Missing in Vendor');
    }

    // Sheet 4: Extra in Vendor
    if (extraInVendor.length) {
      const rows = extraInVendor.slice(0, 100000).map(m => ({ Key: m.key, Status: 'Extra in Vendor', ...m.vndRow }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), 'Extra in Vendor');
    }

    // Sheet 5: Field Diffs
    if (fieldDiffs.length) {
      const rows = fieldDiffs.slice(0, 100000).map(d => ({
        RecordKey: d.key, Column: d.column, VendorColumn: d.vendorColumn,
        InternalValue: d.internalValue, VendorValue: d.vendorValue
      }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), 'Field Differences');
    }

    // Sheet 6: Schema
    if (schemaComparison) {
      const rows = [
        ['COLUMN', 'STATUS'],
        ...(schemaComparison.common       || []).map(c => [c, 'Common']),
        ...(schemaComparison.internalOnly || []).map(c => [c, 'Internal Only']),
        ...(schemaComparison.vendorOnly   || []).map(c => [c, 'Vendor Only']),
        [],
        ['Internal Column', 'Vendor Column'],
        ...(schemaComparison.mapped || []).map(m => [m.internal || m.internalCol, m.vendor || m.vendorCol])
      ];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), 'Schema');
    }

    const filePath = path.join(this.dir, filename);
    XLSX.writeFile(wb, filePath);
    return filePath;
  }

  // ─── CSV ────────────────────────────────────────────────────────────────
  async generateCsv(data, filename) {
    if (!data || !data.length) throw new Error('No data to export');
    const csv = XLSX.utils.sheet_to_csv(XLSX.utils.json_to_sheet(data));
    const fp  = path.join(this.dir, filename);
    await fs.writeFile(fp, csv, 'utf8');
    return fp;
  }

  // ─── PDF summary ─────────────────────────────────────────────────────────
  async generatePdf(result, filename) {
    const { summary, analytics } = result;
    const fp = path.join(this.dir, filename);

    return new Promise((resolve, reject) => {
      const doc = new PDFDocument({ margin: 50 });
      const ws  = fs.createWriteStream(fp);
      doc.pipe(ws);

      doc.fontSize(22).fillColor('#1e40af').text('Data Comparison Report', { align: 'center' });
      doc.fontSize(10).fillColor('#6b7280').text('Generated: ' + new Date().toLocaleString(), { align: 'center' });
      doc.moveDown(1.5);

      doc.fontSize(14).fillColor('#111827').text('Summary', { underline: true });
      doc.moveDown(0.5);
      [
        ['Internal Records',    summary.totalInternal],
        ['Vendor Records',      summary.totalVendor],
        ['Matched (exact)',     summary.matchedExact || result.matched.filter(m => !m.hasDiffs).length],
        ['Mismatched',          summary.mismatched   || result.matched.filter(m => m.hasDiffs).length],
        ['Missing in Vendor',   summary.missingInVendor],
        ['Extra in Vendor',     summary.extraInVendor],
        ['Field Differences',   summary.fieldDifferences || result.fieldDiffs.length],
        ['Match Rate',          summary.matchRate + '%'],
        ['Processing Time',     (summary.durationMs || 0).toLocaleString() + ' ms'],
        ['Throughput',          (summary.rowsPerSec || 0).toLocaleString() + ' rows/sec'],
      ].forEach(([k, v]) => {
        doc.fontSize(10).fillColor('#374151').text(k + ':', { continued: true }).fillColor('#111827').text('  ' + (v ?? '—'));
      });

      const top = (analytics?.topDiffColumns || summary.topDiffColumns || []).slice(0, 10);
      if (top.length) {
        doc.moveDown(1).fontSize(14).fillColor('#111827').text('Top Mismatched Columns', { underline: true });
        doc.moveDown(0.5);
        top.forEach(d => doc.fontSize(10).fillColor('#374151').text(`  • ${d.column || d.col}: ${d.count} diffs (${d.pct || 0}%)`));
      }

      doc.moveDown(2).fontSize(8).fillColor('#9ca3af').text('Generated by Data Comparison Tool v2.0', { align: 'center' });
      doc.end();
      ws.on('finish', () => resolve(fp));
      ws.on('error', reject);
    });
  }

  _prefix(pfx, row) {
    if (!row) return {};
    const out = {};
    for (const [k, v] of Object.entries(row)) out[pfx + k] = v;
    return out;
  }

  async listReports() {
    const files = await fs.readdir(this.dir).catch(() => []);
    const out   = [];
    for (const f of files.filter(f => /\.(xlsx|csv|pdf)$/i.test(f))) {
      try {
        const stat = await fs.stat(path.join(this.dir, f));
        out.push({ filename: f, size: stat.size, created: stat.birthtime, format: path.extname(f).slice(1).toLowerCase() });
      } catch {}
    }
    return out.sort((a, b) => new Date(b.created) - new Date(a.created));
  }

  async deleteReport(filename) {
    await fs.remove(path.join(this.dir, filename));
  }
}

module.exports = new ReportGenerator();
